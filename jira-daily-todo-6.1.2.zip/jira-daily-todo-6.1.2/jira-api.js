const TODAY_JQL = `(
    "Assembly Time Start" is not EMPTY
    AND (
      (
        "Assembly Time Start" >= startOfDay()
        AND "Assembly Time Start" <= endOfDay()
      )
      OR (
        "Dismantling Time" >= startOfDay()
        AND "Dismantling Time" <= endOfDay()
      )
    )
    AND status not in (Resolved, Cancelled, Closed)
  )
  OR (
    labels = "ITA-Auftrag"
    AND Einsatzzeit >= startOfDay()
    AND Einsatzzeit <= endOfDay()
    AND status not in (Resolved, Cancelled, Closed)
  )
  OR (
    component in ("Präsentationsmedien", "Rent-A-Notebook", "ReserWUtion")
    AND "Start time" >= startOfDay()
    AND "Start time" <= endOfDay()
    AND status not in (Resolved, Cancelled, Closed)
  )
  ORDER BY "Assembly Time Start" ASC, "Dismantling Time" ASC, Einsatzzeit ASC, "Start time" ASC`;

const RANGE_JQL = `(
    "Assembly Time Start" is not EMPTY
    AND (
      (
        "Assembly Time Start" >= startOfDay(-14)
        AND "Assembly Time Start" <= endOfDay(3)
      )
      OR (
        "Dismantling Time" >= startOfDay(-14)
        AND "Dismantling Time" <= endOfDay(3)
      )
    )
    AND status not in (Resolved, Cancelled, Closed)
  )
  OR (
    labels = "ITA-Auftrag"
    AND Einsatzzeit >= startOfDay(-14)
    AND Einsatzzeit <= endOfDay(3)
    AND status not in (Resolved, Cancelled, Closed)
  )
  OR (
    component in ("Präsentationsmedien", "Rent-A-Notebook", "ReserWUtion")
    AND "Start time" >= startOfDay(-14)
    AND "Start time" <= endOfDay(3)
    AND status not in (Resolved, Cancelled, Closed)
  )
  ORDER BY "Assembly Time Start" ASC, "Dismantling Time" ASC, Einsatzzeit ASC, "Start time" ASC`;

const DEFAULT_CONFIG = {
  baseUrl: 'https://support.wu.ac.at',
  searchEndpoint: '/rest/api/2/search',
  maxResults: 200,
  fieldAssembly: 'customfield_19322',
  fieldEventEnd: 'customfield_10517',
  fieldEinsatz: 'customfield_18701',
  fieldStart: 'customfield_10518',
  labelAssembly: 'Assembly Time Start',
  labelEventEnd: 'Dismantling Time',
  labelEinsatz: 'Einsatzzeit',
  labelStart: 'Start Time',
  activePreset: 'today',
  customStartDay: -14,
  customEndDay: 3,
  jql: TODAY_JQL,
  jqlToday: TODAY_JQL,
  jqlRange: RANGE_JQL
};

function dayExpression(day) {
  if (day === 0) return '()';
  return `(${day})`;
}

function buildCustomJql(startDay, endDay) {
  const startExpr = dayExpression(startDay);
  const endExpr = dayExpression(endDay);
  return `(
    "Assembly Time Start" is not EMPTY
    AND (
      (
        "Assembly Time Start" >= startOfDay${startExpr}
        AND "Assembly Time Start" <= endOfDay${endExpr}
      )
      OR (
        "Dismantling Time" >= startOfDay${startExpr}
        AND "Dismantling Time" <= endOfDay${endExpr}
      )
    )
    AND status not in (Resolved, Cancelled, Closed)
  )
  OR (
    labels = "ITA-Auftrag"
    AND Einsatzzeit >= startOfDay${startExpr}
    AND Einsatzzeit <= endOfDay${endExpr}
    AND status not in (Resolved, Cancelled, Closed)
  )
  OR (
    component in ("Präsentationsmedien", "Rent-A-Notebook", "ReserWUtion")
    AND "Start time" >= startOfDay${startExpr}
    AND "Start time" <= endOfDay${endExpr}
    AND status not in (Resolved, Cancelled, Closed)
  )
  ORDER BY "Assembly Time Start" ASC, "Dismantling Time" ASC, Einsatzzeit ASC, "Start time" ASC`;
}

export async function getStoredConfig() {
  const stored = await chrome.storage.local.get(DEFAULT_CONFIG);
  return { ...DEFAULT_CONFIG, ...stored };
}

export async function saveConfig(config) {
  await chrome.storage.local.set(config);
}

export async function resetConfig() {
  await chrome.storage.local.set(DEFAULT_CONFIG);
  return DEFAULT_CONFIG;
}

export async function setActivePreset(activePreset) {
  await chrome.storage.local.set({ activePreset });
}

export async function ensureStartupDefaults() {
  const markerKey = 'jiraDailyTodoStartupDefaultsV18';
  const stored = await chrome.storage.local.get([markerKey]);
  if (stored[markerKey]) return;

  await chrome.storage.local.set({
    activePreset: 'today',
    jql: TODAY_JQL,
    [markerKey]: true
  });
}

export async function saveCustomRange(customStartDay, customEndDay) {
  await chrome.storage.local.set({ customStartDay, customEndDay, activePreset: 'custom' });
}

export function getPresetLabel(activePreset, config = {}) {
  if (activePreset === 'today') return 'Heute';
  if (activePreset === 'range') return '-14 Tage bis +3';
  if (activePreset === 'custom') return `Erweitert: ${config.customStartDay ?? -14} bis +${config.customEndDay ?? 3}`;
  return 'Unbekannt';
}

function resolveEffectiveJql(config) {
  if (config.activePreset === 'today') return config.jqlToday || TODAY_JQL;
  if (config.activePreset === 'range') return config.jqlRange || RANGE_JQL;
  if (config.activePreset === 'custom') return buildCustomJql(Number(config.customStartDay) || 0, Number(config.customEndDay) || 0);
  return config.jql || RANGE_JQL;
}

async function fetchSearchPage(config, fields, startAt) {
  const response = await fetch(`${config.baseUrl}${config.searchEndpoint}`, {
    method: 'POST',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify({
      jql: resolveEffectiveJql(config),
      startAt,
      maxResults: Number(config.maxResults) || 200,
      fields
    })
  });

  if (!response.ok) {
    throw new Error(`Jira-Request fehlgeschlagen: ${response.status} ${response.statusText}`);
  }

  return response.json();
}

export async function fetchJiraIssuesForPreset(presetOverride = null) {
  const storedConfig = await getStoredConfig();
  const config = presetOverride ? { ...storedConfig, activePreset: presetOverride } : storedConfig;
  const fields = [
    'summary',
    'status',
    config.fieldAssembly,
    config.fieldEventEnd,
    config.fieldEinsatz,
    config.fieldStart
  ].filter(Boolean);

  const pageSize = Number(config.maxResults) || 200;
  const firstPage = await fetchSearchPage(config, fields, 0);
  const issues = Array.isArray(firstPage.issues) ? [...firstPage.issues] : [];
  const total = Number(firstPage.total) || issues.length;

  for (let startAt = issues.length; startAt < total; startAt += pageSize) {
    const nextPage = await fetchSearchPage(config, fields, startAt);
    if (!Array.isArray(nextPage.issues) || nextPage.issues.length === 0) break;
    issues.push(...nextPage.issues);
  }

  return { data: { ...firstPage, issues, total }, config };
}

export async function fetchJiraIssues() {
  return fetchJiraIssuesForPreset();
}
