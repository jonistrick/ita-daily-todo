function buildFieldPriority(config) {
  return [
    { id: config.fieldAssembly, label: config.labelAssembly || 'Assembly Time Start', type: 'Event', task: 'Aufbau' },
    { id: config.fieldEventEnd, label: config.labelEventEnd || 'Dismantling Time', type: 'Event', task: 'Abbau' },
    { id: config.fieldEinsatz, label: config.labelEinsatz || 'Einsatzzeit', type: 'Auftrag', task: null },
    { id: config.fieldStart, label: config.labelStart || 'Start Time', type: 'ReserWUtion', task: null }
  ].filter(field => field.id);
}

function formatDateTime(value) {
  const date = new Date(value);
  return new Intl.DateTimeFormat('de-AT', {
    timeZone: 'Europe/Vienna',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
}

function getTimingClass(displayTime) {
  const now = new Date();
  const issueDate = new Date(displayTime);
  if (issueDate < now) return 'status-overdue';
  const diffMs = issueDate.getTime() - now.getTime();
  const diffHours = diffMs / (1000 * 60 * 60);
  if (diffHours <= 24) return 'status-upcoming';
  return 'status-normal';
}

function isAllowedForIssue(field, fields, config) {
  const isEventIssue = Boolean(fields[config.fieldAssembly]);

  if (field.id === config.fieldEventEnd) {
    return isEventIssue;
  }

  if (field.id === config.fieldEinsatz) {
    return !isEventIssue;
  }

  return true;
}

function buildEntry(issue, baseUrl, field, value) {
  const fields = issue.fields || {};
  const sourceLabel = field.task ? `${field.label} (${field.task})` : field.label;
  return {
    key: issue.key,
    summary: fields.summary || '(ohne Summary)',
    status: fields.status?.name || 'Unbekannt',
    ticketType: field.type,
    taskType: field.task,
    url: `${baseUrl}/browse/${issue.key}`,
    displayTimeRaw: value,
    displayTimeFormatted: formatDateTime(value),
    sourceField: sourceLabel,
    sourceFieldId: field.id,
    timingClass: getTimingClass(value)
  };
}

export function mapAndSortIssues(issues, baseUrl, config) {
  const rows = [];
  const seen = new Set();

  for (const issue of issues || []) {
    const fields = issue.fields || {};

    for (const field of buildFieldPriority(config)) {
      if (!isAllowedForIssue(field, fields, config)) continue;
      const value = fields[field.id];
      if (!value) continue;

      const dedupeKey = `${issue.key}::${field.id}::${value}`;
      if (seen.has(dedupeKey)) continue;
      seen.add(dedupeKey);

      rows.push(buildEntry(issue, baseUrl, field, value));
    }
  }

  return rows.sort((a, b) => {
    const timeDiff = new Date(a.displayTimeRaw) - new Date(b.displayTimeRaw);
    if (timeDiff !== 0) return timeDiff;
    return a.key.localeCompare(b.key, 'de');
  });
}
