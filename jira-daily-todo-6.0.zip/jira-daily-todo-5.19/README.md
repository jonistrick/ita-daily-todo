Version 5.2 Satisfying
- Checkbox pro Eintrag, nur lokal gespeichert und automatisch pro Tag getrennt.
- Beim erneuten Öffnen scrollt die Liste zur ersten offenen Aufgabe.
- Erledigte bleiben oberhalb erhalten und sind durch Hochscrollen sichtbar.
- Satisfying Design: lebendige grüne Check-Animation, weicher Pulseffekt, freundlichere Done-Fläche.
