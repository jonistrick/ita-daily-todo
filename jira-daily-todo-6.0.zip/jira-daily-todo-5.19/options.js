import { getStoredConfig, resetConfig, saveConfig } from './jira-api.js';

const fieldIds = [
  'baseUrl', 'searchEndpoint', 'maxResults',
  'fieldAssembly', 'labelAssembly',
  'fieldEventEnd', 'labelEventEnd',
  'fieldEinsatz', 'labelEinsatz',
  'fieldStart', 'labelStart',
  'jqlToday', 'jqlRange'
];

const form = document.getElementById('configForm');
const resetBtn = document.getElementById('resetBtn');
const saveMessage = document.getElementById('saveMessage');

function fillForm(config) {
  for (const id of fieldIds) {
    const el = document.getElementById(id);
    if (el) el.value = config[id] ?? '';
  }
}

function collectFormValues() {
  const config = {};
  for (const id of fieldIds) {
    const el = document.getElementById(id);
    config[id] = el?.value ?? '';
  }
  config.maxResults = Number(config.maxResults) || 200;
  config.jql = config.jqlRange;
  return config;
}

async function init() {
  const config = await getStoredConfig();
  fillForm(config);
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const config = collectFormValues();
  await saveConfig(config);
  saveMessage.textContent = 'Einstellungen gespeichert.';
});

resetBtn.addEventListener('click', async () => {
  const config = await resetConfig();
  fillForm(config);
  saveMessage.textContent = 'Standardwerte wurden geladen.';
});

document.addEventListener('DOMContentLoaded', init);
