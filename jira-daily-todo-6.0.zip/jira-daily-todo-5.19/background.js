import { fetchJiraIssuesForPreset, getPresetLabel } from './jira-api.js';
import { mapAndSortIssues } from './mapper.js';

const POLL_ALARM = 'jiraDailyTodoPoll';
const POLL_INTERVAL_MINUTES = 5;
const SNAPSHOT_PREFIX = 'jiraDailyTodoSnapshot';
const ALERT_STORAGE_KEY = 'jiraDailyTodoNewAlert';
const NOTIFICATION_ID = 'jiraDailyTodoNewIssueNotification';
const ALERT_PRESET = 'today';

function getTodayKey() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Vienna',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());
}

function buildItemId(item) {
  return [item.key, item.sourceFieldId, item.displayTimeRaw].join('::');
}

function buildSnapshotKey() {
  return `${SNAPSHOT_PREFIX}:${getTodayKey()}:${ALERT_PRESET}`;
}

function getBadgeText(count) {
  if (!count) return '';
  return count > 99 ? '99+' : String(count);
}

function buildNotificationMessage(items) {
  if (items.length === 1) {
    return `${items[0].key}: ${items[0].summary}`;
  }

  const preview = items
    .slice(0, 3)
    .map(item => item.key)
    .join(', ');

  return `${items.length} neue Einträge in Heute: ${preview}${items.length > 3 ? ', ...' : ''}`;
}

async function ensureAlarm() {
  const existing = await chrome.alarms.get(POLL_ALARM);
  if (existing) return;

  await chrome.alarms.create(POLL_ALARM, {
    delayInMinutes: 1,
    periodInMinutes: POLL_INTERVAL_MINUTES
  });
}

async function clearExpiredAlertIfNeeded() {
  const store = await chrome.storage.local.get(ALERT_STORAGE_KEY);
  const alert = store[ALERT_STORAGE_KEY];
  if (!alert || alert.dateKey === getTodayKey()) return;

  await chrome.storage.local.remove(ALERT_STORAGE_KEY);
  await chrome.action.setBadgeText({ text: '' });
  await chrome.notifications.clear(NOTIFICATION_ID);
}

async function pollForNewItems() {
  await clearExpiredAlertIfNeeded();

  try {
    const { data, config } = await fetchJiraIssuesForPreset(ALERT_PRESET);
    const issues = Array.isArray(data.issues) ? data.issues : [];
    const items = mapAndSortIssues(issues, config.baseUrl, config);
    const snapshotKey = buildSnapshotKey();
    const stored = await chrome.storage.local.get(snapshotKey);
    const previousIds = Array.isArray(stored[snapshotKey]) ? stored[snapshotKey] : null;
    const currentIds = items.map(buildItemId);

    await chrome.storage.local.set({ [snapshotKey]: currentIds });

    if (!previousIds) {
      return;
    }

    const previousIdSet = new Set(previousIds);
    const newItems = items.filter(item => !previousIdSet.has(buildItemId(item)));
    if (!newItems.length) {
      return;
    }

    const alertPayload = {
      dateKey: getTodayKey(),
      createdAt: new Date().toISOString(),
      preset: ALERT_PRESET,
      presetLabel: getPresetLabel(ALERT_PRESET, config),
      count: newItems.length,
      items: newItems.map(item => ({
        key: item.key,
        summary: item.summary,
        url: item.url,
        displayTimeFormatted: item.displayTimeFormatted,
        sourceField: item.sourceField,
        ticketType: item.ticketType,
        taskType: item.taskType
      }))
    };

    await chrome.storage.local.set({ [ALERT_STORAGE_KEY]: alertPayload });
    await chrome.action.setBadgeBackgroundColor({ color: '#b91c1c' });
    await chrome.action.setBadgeText({ text: getBadgeText(newItems.length) });

    await chrome.notifications.create(NOTIFICATION_ID, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: newItems.length === 1 ? 'Neues Ticket in Heute' : 'Neue Tickets in Heute',
      message: buildNotificationMessage(newItems),
      priority: 2,
      requireInteraction: true
    });
  } catch (error) {
    console.error('Polling für neue Jira-Tickets fehlgeschlagen', error);
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  await ensureAlarm();
  await pollForNewItems();
});

chrome.runtime.onStartup.addListener(async () => {
  await ensureAlarm();
  await pollForNewItems();
});

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name !== POLL_ALARM) return;
  await pollForNewItems();
});
