import {
  ensureStartupDefaults,
  fetchJiraIssues,
  getPresetLabel,
  getStoredConfig,
  saveCustomRange,
  setActivePreset
} from './jira-api.js';
import { mapAndSortIssues } from './mapper.js';

const statusText = document.getElementById('statusText');
const metaText = document.getElementById('metaText');
const tableBody = document.getElementById('ticketTableBody');
const tableWrap = document.getElementById('tableWrap');
const celebrationLayer = document.getElementById('celebrationLayer');
const celebrationBurst = document.getElementById('celebrationBurst');
const celebrationBadge = document.getElementById('celebrationBadge');
const refreshBtn = document.getElementById('refreshBtn');
const settingsBtn = document.getElementById('settingsBtn');
const todayPresetBtn = document.getElementById('todayPresetBtn');
const rangePresetBtn = document.getElementById('rangePresetBtn');
const advancedToggleBtn = document.getElementById('advancedToggleBtn');
const advancedPanel = document.getElementById('advancedPanel');
const startDaySlider = document.getElementById('startDaySlider');
const endDaySlider = document.getElementById('endDaySlider');
const startDayValue = document.getElementById('startDayValue');
const endDayValue = document.getElementById('endDayValue');
const applyAdvancedBtn = document.getElementById('applyAdvancedBtn');

const DONE_STORAGE_PREFIX = 'jiraDailyTodoDone';
const ALERT_STORAGE_KEY = 'jiraDailyTodoNewAlert';
const PENDING_HIGHLIGHT_STORAGE_KEY = 'jiraDailyTodoPendingHighlight';
const NOTIFICATION_ID = 'jiraDailyTodoNewIssueNotification';
let celebrationTimeout = null;

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function getTodayKey() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Vienna',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());
}

function getDoneStorageKey() {
  return `${DONE_STORAGE_PREFIX}:${getTodayKey()}`;
}

function readDoneMap() {
  try {
    const raw = localStorage.getItem(getDoneStorageKey());
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function writeDoneMap(map) {
  localStorage.setItem(getDoneStorageKey(), JSON.stringify(map));
}

async function clearNewIssueAlert() {
  try {
    await chrome.storage.local.remove(ALERT_STORAGE_KEY);
    await chrome.action.setBadgeText({ text: '' });
    await chrome.notifications.clear(NOTIFICATION_ID);
  } catch (error) {
    console.error('Konnte New-Issue-Alert nicht zurücksetzen', error);
  }
}

async function consumePendingHighlight() {
  const store = await chrome.storage.local.get(PENDING_HIGHLIGHT_STORAGE_KEY);
  const pending = store[PENDING_HIGHLIGHT_STORAGE_KEY];
  await chrome.storage.local.remove(PENDING_HIGHLIGHT_STORAGE_KEY);

  if (!pending || pending.dateKey !== getTodayKey()) {
    return null;
  }

  return pending;
}

function highlightRows(itemIds = []) {
  if (!itemIds.length) {
    scrollToFirstOpenRow();
    return;
  }

  requestAnimationFrame(() => {
    const highlightedRows = itemIds
      .map(itemId => tableBody.querySelector(`.todo-row[data-item-id="${CSS.escape(itemId)}"]`))
      .filter(Boolean);

    if (!highlightedRows.length) {
      scrollToFirstOpenRow();
      return;
    }

    const firstRow = highlightedRows[0];
    tableWrap.scrollTop = Math.max(0, firstRow.offsetTop - 72);

    highlightedRows.forEach(row => {
      row.classList.add('is-notification-highlight');
      row.classList.add('is-notification-persistent');
      window.setTimeout(() => row.classList.remove('is-notification-highlight'), 10000);
      window.setTimeout(() => row.classList.remove('is-notification-persistent'), 70000);
    });
  });
}

function buildItemId(item) {
  return [item.key, item.sourceFieldId, item.displayTimeRaw].join('::');
}

function formatSignedDay(value) {
  const num = Number(value);
  return num > 0 ? `+${num}` : `${num}`;
}

function updateSliderLabels() {
  startDayValue.textContent = formatSignedDay(startDaySlider.value);
  endDayValue.textContent = formatSignedDay(endDaySlider.value);
}

function toggleAdvancedPanel(forceOpen = null) {
  const shouldOpen = forceOpen === null ? advancedPanel.classList.contains('is-hidden') : forceOpen;
  advancedPanel.classList.toggle('is-hidden', !shouldOpen);
  advancedToggleBtn.classList.toggle('is-open', shouldOpen);
  advancedToggleBtn.setAttribute('aria-expanded', String(shouldOpen));
}

function renderPresetButtons(activePreset) {
  todayPresetBtn.classList.toggle('is-active', activePreset === 'today');
  rangePresetBtn.classList.toggle('is-active', activePreset === 'range');
  advancedToggleBtn.classList.toggle('is-active', activePreset === 'custom');
}

function setButtonsDisabled(isDisabled) {
  refreshBtn.disabled = isDisabled;
  settingsBtn.disabled = isDisabled;
  todayPresetBtn.disabled = isDisabled;
  rangePresetBtn.disabled = isDisabled;
  advancedToggleBtn.disabled = isDisabled;
  applyAdvancedBtn.disabled = isDisabled;
  startDaySlider.disabled = isDisabled;
  endDaySlider.disabled = isDisabled;
}

function getTicketTypeClass(ticketType) {
  if (ticketType === 'Event' || ticketType === 'Auftrag') return 'ticket-type-red';
  if (ticketType === 'ReserWUtion') return 'ticket-type-gray';
  return 'ticket-type-default';
}

function getDoneLabel(item) {
  return item.taskType ? `${item.ticketType} - ${item.taskType}` : item.ticketType;
}

function currentPresetIsToday() {
  return todayPresetBtn.classList.contains('is-active');
}

function scrollToFirstOpenRow() {
  requestAnimationFrame(() => {
    const rows = Array.from(tableBody.querySelectorAll('.todo-row'));
    if (!rows.length) return;
    const firstOpen = rows.find(row => !row.classList.contains('is-done'));
    if (firstOpen) {
      tableWrap.scrollTop = Math.max(0, firstOpen.offsetTop - 46);
      return;
    }
    tableWrap.scrollTop = tableWrap.scrollHeight;
  });
}

function clearCelebrationParticles() {
  celebrationBurst.innerHTML = '';
}

function spawnParticles() {
  clearCelebrationParticles();
  const symbols = ['✦', '✦', '✦', '★', '★', '✶', '✶', '✷'];

  for (let i = 0; i < 26; i += 1) {
    const particle = document.createElement('span');
    particle.className = i % 3 === 0 ? 'celebration-particle is-star' : 'celebration-particle';
    particle.textContent = symbols[i % symbols.length];
    particle.style.setProperty('--x-start', `${8 + (i % 6) * 16}%`);
    particle.style.setProperty('--delay', `${(i % 8) * 45}ms`);
    particle.style.setProperty('--duration', `${1100 + (i % 5) * 140}ms`);
    particle.style.setProperty('--drift', `${-120 + (i * 11) % 240}px`);
    particle.style.setProperty('--rotate', `${-160 + (i * 27) % 320}deg`);
    particle.style.setProperty('--size', `${15 + (i % 4) * 4}px`);
    celebrationBurst.appendChild(particle);
  }
}

function celebrateCompletion() {
  if (!currentPresetIsToday()) return;
  spawnParticles();
  celebrationLayer.classList.remove('is-active');
  tableWrap.classList.remove('all-done');
  void celebrationLayer.offsetWidth;
  celebrationBadge.textContent = 'Alles erledigt!';
  celebrationLayer.classList.add('is-active');
  tableWrap.classList.add('all-done');
  window.clearTimeout(celebrationTimeout);
  celebrationTimeout = window.setTimeout(() => {
    celebrationLayer.classList.remove('is-active');
    tableWrap.classList.remove('all-done');
    clearCelebrationParticles();
  }, 1700);
}

function bindDoneInteractions() {
  const doneMap = readDoneMap();
  const rows = Array.from(tableBody.querySelectorAll('.todo-row'));

  rows.forEach(row => {
    const checkbox = row.querySelector('.done-checkbox');
    const itemId = row.dataset.itemId;

    checkbox.addEventListener('change', () => {
      if (checkbox.checked) {
        doneMap[itemId] = true;
        row.classList.add('is-done', 'just-completed');
        window.setTimeout(() => row.classList.remove('just-completed'), 700);
      } else {
        delete doneMap[itemId];
        row.classList.remove('is-done', 'just-completed');
        celebrationLayer.classList.remove('is-active');
        tableWrap.classList.remove('all-done');
        window.clearTimeout(celebrationTimeout);
        clearCelebrationParticles();
      }

      writeDoneMap(doneMap);
      const allRows = Array.from(tableBody.querySelectorAll('.todo-row'));
      if (allRows.length && allRows.every(item => item.classList.contains('is-done'))) {
        celebrateCompletion();
      }
    });
  });
}

function renderRows(items, highlightIds = []) {
  const doneMap = readDoneMap();

  if (!items.length) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="6" class="empty-row">Keine passenden Tickets gefunden.</td>
      </tr>
    `;
    celebrationLayer.classList.remove('is-active');
    tableWrap.classList.remove('all-done');
    clearCelebrationParticles();
    return;
  }

  tableBody.innerHTML = items.map(item => {
    const itemId = buildItemId(item);
    const isDone = Boolean(doneMap[itemId]);

    return `
      <tr class="todo-row ${isDone ? 'is-done' : ''}" data-item-id="${escapeHtml(itemId)}">
        <td class="done-cell">
          <label class="done-toggle" title="Eintrag erledigt markieren">
            <input class="done-checkbox" type="checkbox" ${isDone ? 'checked' : ''} aria-label="${escapeHtml(item.summary)} erledigt">
            <span class="done-ui"></span>
          </label>
        </td>
        <td class="time-cell">
          <span class="time-main" title="${escapeHtml(item.displayTimeFormatted)}">${escapeHtml(item.displayTimeFormatted)}</span>
          <span class="source-note" title="${escapeHtml(item.sourceField)}">${escapeHtml(item.sourceField)}</span>
        </td>
        <td class="ticket-type-cell">
          <span class="ticket-type-badge ${getTicketTypeClass(item.ticketType)}" title="${escapeHtml(getDoneLabel(item))}">${escapeHtml(getDoneLabel(item))}</span>
        </td>
        <td class="key-cell">
          <a class="key-link" href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer" title="${escapeHtml(item.key)}">
            ${escapeHtml(item.key)}
          </a>
        </td>
        <td class="status-cell">
          <span class="status-badge ${escapeHtml(item.timingClass)}" title="${escapeHtml(item.status)}">${escapeHtml(item.status)}</span>
        </td>
        <td class="summary-cell">
          <a class="row-link" href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer" title="${escapeHtml(item.summary)}">
            ${escapeHtml(item.summary)}
          </a>
        </td>
      </tr>
    `;
  }).join('');

  bindDoneInteractions();
  highlightRows(highlightIds);
}

function renderError(message) {
  tableBody.innerHTML = `
    <tr>
      <td colspan="6" class="error-row">${escapeHtml(message)}</td>
    </tr>
  `;
}

async function loadTickets(highlightIds = []) {
  const currentConfig = await getStoredConfig();
  renderPresetButtons(currentConfig.activePreset);
  startDaySlider.value = currentConfig.customStartDay ?? -14;
  endDaySlider.value = currentConfig.customEndDay ?? 3;
  updateSliderLabels();
  statusText.textContent = 'Lade Tickets...';
  metaText.textContent = 'Jira-Session wird verwendet.';
  tableBody.innerHTML = `
    <tr>
      <td colspan="6" class="placeholder">Lade Daten...</td>
    </tr>
  `;
  setButtonsDisabled(true);
  celebrationLayer.classList.remove('is-active');
  tableWrap.classList.remove('all-done');
  window.clearTimeout(celebrationTimeout);
  clearCelebrationParticles();

  try {
    const { data, config } = await fetchJiraIssues();
    const issues = Array.isArray(data.issues) ? data.issues : [];
    const items = mapAndSortIssues(issues, config.baseUrl, config);

    renderPresetButtons(config.activePreset);
    renderRows(items, highlightIds);
    metaText.textContent = `Ansicht: ${getPresetLabel(config.activePreset, config)} | Basis-URL: ${config.baseUrl}`;
    statusText.textContent = `${items.length} Tickets geladen`;
  } catch (error) {
    console.error(error);
    statusText.textContent = 'Fehler beim Laden';
    metaText.textContent = 'Bitte prüfen, ob du in Jira eingeloggt bist und die Berechtigung hast.';
    renderError(error.message || 'Unbekannter Fehler');
  } finally {
    setButtonsDisabled(false);
  }
}

async function switchPreset(preset) {
  await setActivePreset(preset);
  if (preset !== 'custom') toggleAdvancedPanel(false);
  await loadTickets();
}

async function applyAdvancedPreset() {
  await saveCustomRange(Number(startDaySlider.value), Number(endDaySlider.value));
  toggleAdvancedPanel(true);
  await loadTickets();
}

refreshBtn.addEventListener('click', loadTickets);
settingsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());
todayPresetBtn.addEventListener('click', () => switchPreset('today'));
rangePresetBtn.addEventListener('click', () => switchPreset('range'));
advancedToggleBtn.addEventListener('click', () => toggleAdvancedPanel());
applyAdvancedBtn.addEventListener('click', applyAdvancedPreset);
startDaySlider.addEventListener('input', updateSliderLabels);
endDaySlider.addEventListener('input', updateSliderLabels);

document.addEventListener('DOMContentLoaded', async () => {
  toggleAdvancedPanel(false);
  await ensureStartupDefaults();
  const pendingHighlight = await consumePendingHighlight();

  if (pendingHighlight?.preset === 'today') {
    await setActivePreset('today');
  }

  await loadTickets(pendingHighlight?.highlightIds || []);
  await clearNewIssueAlert();
});
